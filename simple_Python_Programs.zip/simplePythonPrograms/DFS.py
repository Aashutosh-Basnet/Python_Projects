def DFS(adjacency_matrix, start_vertex, vertices, visited):
    visited[start_vertex] = True
    print(start_vertex+1, end=' ')

    for i in range(vertices):
        if adjacency_matrix[start_vertex][i] == 1 and not visited[i]:
            DFS(adjacency_matrix, i, vertices, visited)

def main():
    vertices = int(input("Enter the number of vertices: "))
    edges = int(input("Enter the number of Edges: "))

    adjacency_matrix = [[0] * vertices for _ in range(vertices)]

    print("Enter edge pairs:")
    for _ in range(edges):
        u, v = map(int, input().split())
        adjacency_matrix[u - 1][v - 1] = 1  # Adjusting indices to start from 0
        adjacency_matrix[v - 1][u - 1] = 1  # Adjusting indices to start from 0

    start_vertex = int(input("Enter the starting vertex: ")) - 1  # Adjusting index to start from 0

    visited = [False] * vertices

    print("DFS Traversal:", end=' ')
    DFS(adjacency_matrix, start_vertex, vertices, visited)

if __name__ == "__main__":
    main()
