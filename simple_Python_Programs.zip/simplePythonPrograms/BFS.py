import heapq

class Graph:
    def __init__(self, vertices):
        self.vertices = vertices
        self.adjacency_list = {vertex: {} for vertex in range(vertices)}

    def add_edge(self, u, v, weight):
        self.adjacency_list[u][v] = weight

    def uniform_cost_search(self, start, goal):
        frontier = []
        heapq.heappush(frontier, (0, start))  # (cost, node)
        cost_so_far = {start: 0}
        came_from = {start: None}

        while frontier:
            current_cost, current_node = heapq.heappop(frontier)

            if current_node == goal:
                path = []
                while current_node:
                    path.append(current_node)
                    current_node = came_from[current_node]
                return path[::-1]

            for neighbor, cost in self.adjacency_list[current_node].items():
                new_cost = current_cost + cost
                if neighbor not in cost_so_far or new_cost < cost_so_far[neighbor]:
                    cost_so_far[neighbor] = new_cost
                    heapq.heappush(frontier, (new_cost, neighbor))
                    came_from[neighbor] = current_node

        return None

def main():
    vertices = int(input("Enter the number of vertices: "))
    edges = int(input("Enter the number of Edges: "))

    graph = Graph(vertices)

    print("Enter edge pairs with weights:")
    for _ in range(edges):
        u, v, weight = map(int, input().split())
        graph.add_edge(u - 1, v - 1, weight)

    start_vertex = int(input("Enter the starting vertex: ")) - 1

    goal_vertex = int(input("Enter the goal vertex: ")) - 1

    path = graph.uniform_cost_search(start_vertex, goal_vertex)
    if path:
        print("Path found:", ' -> '.join(map(str, path)))
    else:
        print("Goal is not reachable from the start node.")

if __name__ == "__main__":
    main()
