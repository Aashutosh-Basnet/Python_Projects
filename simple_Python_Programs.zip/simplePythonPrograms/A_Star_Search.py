# not sure if it works or not

import heapq

class Graph:
    def __init__(self, vertices):
        self.vertices = vertices
        self.adjacency_list = {vertex: {} for vertex in range(vertices)}
        self.heuristics = [0] * vertices  # Initialize heuristics to zero for all vertices

    def add_edge(self, u, v, weight):
        self.adjacency_list[u][v] = weight

    def set_heuristic(self, vertex, heuristic):
        self.heuristics[vertex] = heuristic

    def a_star_search(self, start, goal):
        frontier = []
        heapq.heappush(frontier, (0, start))  # (priority, node)
        came_from = {start: None}
        cost_so_far = {start: 0}

        while frontier:
            _, current_node = heapq.heappop(frontier)

            if current_node == goal:
                path = []
                while current_node:
                    path.append(current_node+1)
                    current_node = came_from[current_node]
                return path[::-1]

            for neighbor, cost in self.adjacency_list[current_node].items():
                new_cost = cost_so_far[current_node] + cost
                if neighbor not in cost_so_far or new_cost < cost_so_far[neighbor]:
                    cost_so_far[neighbor] = new_cost
                    priority = new_cost + self.heuristics[neighbor]
                    heapq.heappush(frontier, (priority, neighbor))
                    came_from[neighbor] = current_node

        return None

def main():
    vertices = int(input("Enter the number of vertices: "))
    edges = int(input("Enter the number of Edges: "))

    graph = Graph(vertices)

    print("Enter edge pairs with weights:")
    for _ in range(edges):
        u, v, weight = map(int, input().split())
        graph.add_edge(u - 1, v - 1, weight)

    start_vertex = int(input("Enter the starting vertex: ")) - 1
    goal_vertex = int(input("Enter the goal vertex: ")) - 1

    for vertex in range(vertices):
        heuristic = int(input(f"Enter heuristic for vertex {vertex+1}: "))
        graph.set_heuristic(vertex, heuristic)

    path = graph.a_star_search(start_vertex, goal_vertex)
    if path:
        print(f"Path found: {start_vertex+1} ->", ' -> '.join(map(str, path)))
    else:
        print("Goal is not reachable from the start node.")

if __name__ == "__main__":
    main()
